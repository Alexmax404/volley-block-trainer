<script setup lang="ts">
import TrainingScreen from './components/TrainingScreen.vue';
import ControlPanel from './components/ControlPanel.vue';
import RotateDeviceOverlay from './components/RotateDeviceOverlay.vue';
import { useTrainer } from './composables/useTrainer';
import { useFullscreen } from './composables/useFullscreen';

const trainer = useTrainer();
const fullscreen = useFullscreen();

async function handleStart() {
  await fullscreen.enter();
  trainer.start();
}

function handleStop() {
  trainer.stop();
}
</script>

<template>
  <main class="app">
    <TrainingScreen :active-side="trainer.activeSide.value" />
    <ControlPanel :is-running="trainer.isRunning.value" @start="handleStart" @stop="handleStop" />
    <RotateDeviceOverlay />
  </main>
</template>

<style scoped>
.app {
  width: 100vw;
  height: 100vh;
  position: relative;
}
</style>